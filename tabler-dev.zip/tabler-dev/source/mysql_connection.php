<?php

$host = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname = "tabler";
$connection = new mysqli($host, $dbuser, $dbpassword, $dbname);

if($connection->connect_error){
	die($connection->connect_error);
}	

?>